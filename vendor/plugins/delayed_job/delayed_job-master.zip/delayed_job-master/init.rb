require File.dirname(__FILE__) + '/lib/delayed_job'
