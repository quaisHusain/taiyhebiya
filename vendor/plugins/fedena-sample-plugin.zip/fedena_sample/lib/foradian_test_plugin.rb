# ForadianTestPlugin
class ForadianTestPlugin
  unloadable
end